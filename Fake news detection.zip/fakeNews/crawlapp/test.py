import sys
from views import testCrawling
testCrawling()